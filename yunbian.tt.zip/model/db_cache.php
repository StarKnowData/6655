<?php
class db_cache extends ybModel  
{  
	var $pk = "uid"; // 主键  
	var $table = "cache"; // 数据表的名称 


}
?>