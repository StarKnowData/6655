<?php /* Smarty version Smarty-3.0.6, created on 2012-12-21 22:51:00
         compiled from "tplv2\admin/footer.html" */ ?>
<?php /*%%SmartyHeaderCode:1054950d477543da989-47667676%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '339a1bab450b7f24a69570251d6d28a8f40fdcbb' => 
    array (
      0 => 'tplv2\\admin/footer.html',
      1 => 1341038694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1054950d477543da989-47667676',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
  
  <div align="center" id="footer">Powered by  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['version'][0][0]->__soft_V(array(),$_smarty_tpl);?>
 &nbsp;2011-2012 </span></div>
  <td>
  </tr>
  </table>
  </div>
  
</div>

</body>
</html>